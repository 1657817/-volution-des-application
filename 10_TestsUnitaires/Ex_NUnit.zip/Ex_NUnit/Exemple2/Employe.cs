﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exemple2
{
    public class Employe
    {
        public int Id
        {
            get;
            set;
        }
        public string Nom
        {
            get;
            set;
        }
        public double Salaire
        {
            get;
            set;
        }
        public string Genre
        {
            get;
            set;
        }
    }
}
